package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaSamuelApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaSamuelApplication.class, args);
	}

}
